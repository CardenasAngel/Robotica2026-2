#!/usr/bin/env python3
import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import Command
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
  # ── SOLUCIÓN CRÍTICA: Forzamos la ruta directa a tu Workspace local ──
  workspace_path = "/home/robotics/Proyecto_final_robotica/ros/robot_ws"
  
  # Construimos las rutas precisas hacia tus archivos reales
  urdf_path = os.path.join(workspace_path, "src/robot_description/urdf/robot_rrr.urdf")
  rviz_path = os.path.join(workspace_path, "src/robot_description/rviz/rviz.conf.rviz")
  
  # Procesamos el URDF a través de xacro de forma segura
  urdf_xacro = Command(["xacro ", urdf_path])
  
  # Modelo URDF como parámetro para el publicador de estados
  urdf_param = {"robot_description": ParameterValue(urdf_xacro, value_type=str)}
  
  # ── Configuración de Nodos ──
  
  # Visualizador 3D RViz2
  rviz_node = Node(
    package="rviz2",
    executable="rviz2",
    arguments=["-d", rviz_path]
  )
  
  # Publicador del esqueleto estructural del robot
  robot_description_node = Node(
    package="robot_state_publisher",
    executable="robot_state_publisher",
    parameters=[urdf_param]
  )
  
  # Lanzamos únicamente los dos nodos limpios de control
  launch_description = LaunchDescription([
    rviz_node, 
    robot_description_node
  ])
  
  return launch_description