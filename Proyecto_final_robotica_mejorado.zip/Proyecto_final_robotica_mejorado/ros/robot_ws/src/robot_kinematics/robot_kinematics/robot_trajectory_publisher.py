#!/usr/bin/env python3
"""
robot_trajectory_publisher.py
──────────────────────────────────────────────────────────────────────
Nodo ROS 2: Publicador de Trayectoria para el Robot Industrial 3D RRR.

Recibe una posición deseada del efector final (vía clic en RViz con la
herramienta "Publish Point") y publica la trayectoria articular para que
el brazo se mueva suavemente hasta ese punto en el espacio 3D.

Versión Corregida:
  - TH_INIT sincronizado con postura de imagen (q2=-34°, q3=-96°)
  - Usa el Z real del clic (con piso de seguridad de 0.05m)
  - Gráficas generadas en hilo separado (no bloquea el spin ROS)
  - Logs detallados de error de posición final
──────────────────────────────────────────────────────────────────────
"""
import rclpy
from rclpy.node import Node
from robot_kinematics.kinematics import Robot
from geometry_msgs.msg import PointStamped
from sensor_msgs.msg import JointState
import numpy as np

# ── Nombres de juntas — deben coincidir EXACTAMENTE con el URDF ────────────
JOINT_NAMES = ["shoulder_joint", "arm_joint", "forearm_joint"]

# ── Parámetros de la trayectoria ───────────────────────────────────────────
TRAY_TIME = 5.0      # Duración de cada movimiento (s) — aumentado para mayor suavidad
TRAY_FREQ = 50       # Frecuencia de muestreo (Hz)

# ── Postura inicial calibrada (imagen de referencia) ──────────────────────
#   shoulder_joint ≈  0.0  rad (0°)
#   arm_joint      ≈ -0.59 rad (-34°) — brazo ligeramente inclinado adelante
#   forearm_joint  ≈ -1.68 rad (-96°) — antebrazo recogido hacia abajo
TH_INIT = (0.0, -0.59, -1.68)

# ── Altura mínima de seguridad para el efector final ──────────────────────
Z_MIN_SEGURIDAD = 0.05   # metros — evita que el brazo traspase el suelo


class PublicadorTrayectoria(Node):
    def __init__(self):
        super().__init__("nodo_publicador_trayectoria")

        # ── 1. Instanciar la matematica del robot ──────────────────
        self.get_logger().info("Inicializando Robot Industrial 3D RRR...")
        self.get_logger().info("   (Compilando matrices DH — puede tardar ~10s la primera vez)")
        self.robot = Robot()
        self.get_logger().info("Módulo cinemático listo.")

        # ── 2. Conexiones ROS ──────────────────────────────────────────────
        self.sub_ps = self.create_subscription(
            PointStamped, "/clicked_point", self.ps_callback, 1)

        self.js_pub = self.create_publisher(
            JointState, "/joint_states_goals", 10)

        self.js_sub = self.create_subscription(
            JointState, "/joint_states", self.js_callback, 10)

        # ── 3. Estado interno ──────────────────────────────────────────────
        self.is_moving   = False
        self.current_pos = 0

        self.joint_state_msg = JointState()
        self.joint_state_msg.name = JOINT_NAMES

        # Posición inicial conocida del robot
        self.js_current = JointState()
        self.js_current.name     = JOINT_NAMES
        self.js_current.position = list(TH_INIT)

        self.get_logger().info("Nodo listo. Usa 'Publish Point' en RViz para mover el robot.")
        self.get_logger().info(f"   Postura inicial: q1={TH_INIT[0]:.3f}, "
                               f"q2={TH_INIT[1]:.3f}, q3={TH_INIT[2]:.3f} rad")
        # Mostrar posición FK inicial para verificación
        x0 = np.asarray(self.robot.fk_num(*TH_INIT)).flatten()
        self.get_logger().info(f"   FK inicial → X={x0[0]:.3f}, Y={x0[1]:.3f}, Z={x0[2]:.3f} m")

    # ─────────────────────────────────────────────────────────────────────────
    def ps_callback(self, msg: PointStamped):
        """
        Esta función se dispara automáticamente cuando haces clic en la herramienta 'Publish Point' de RViz.
        """
        # Primero, verificamos si el robot ya está trabajando. ¡No lo interrumpas!
        if self.is_moving:
            self.get_logger().warn("Robot en movimiento. Espera a que termine.")
            return
        self.is_moving = True

        # Extraemos las coordenadas X, Y, Z del lugar exacto donde hiciste clic.
        x_dest = float(msg.point.x)
        y_dest = float(msg.point.y)
        # SEGURIDAD: Comparamos la Z de tu clic con Z_MIN_SEGURIDAD.
        # Si hiciste clic por debajo del suelo, el robot lo ignora y apunta al límite seguro.
        z_dest = max(float(msg.point.z), Z_MIN_SEGURIDAD)

        # Ahora que tenemos un punto seguro, iniciamos los cálculos de trayectoria hacia allá.
        self._iniciar_trayectoria((x_dest, y_dest, z_dest))

    # ─────────────────────────────────────────────────────────────────────────
    def _iniciar_trayectoria(self, xi_f: tuple):
        """
        Organiza todo el cálculo matemático necesario para mover el robot desde
        donde está hasta donde le pediste, usando Cinemática Inversa Diferencial.
        """
        # Obtenemos los ángulos actuales de los motores. Si por alguna razón no hay datos,
        # asumimos que el robot está en su posición inicial de fábrica (TH_INIT).
        th_i = tuple(self.js_current.position) if len(self.js_current.position) == 3 else TH_INIT

        self.get_logger().info("─" * 60)
        self.get_logger().info(f"Posición actual de las juntas (rad): "
                               f"q1={th_i[0]:.3f}, q2={th_i[1]:.3f}, q3={th_i[2]:.3f}")
        self.get_logger().info(f"El punto al que quieres llegar es: X={xi_f[0]:.3f}, Y={xi_f[1]:.3f}, Z={xi_f[2]:.3f} m")

        # Calculamos dónde está la punta del robot AHORA MISMO (Cinemática Directa) para mostrarlo en el log.
        x_act = np.asarray(self.robot.fk_num(*th_i)).flatten()
        self.get_logger().info(f"   La punta del robot empezó en → X={x_act[0]:.3f}, Y={x_act[1]:.3f}, Z={x_act[2]:.3f} m")

        # ── ¡AQUÍ ESTÁ EL NÚCLEO MATEMÁTICO! ──
        # Mandamos llamar al archivo kinematics.py para que trace y genere el camino completo súper suave
        self.robot.def_tray(
            t_f=TRAY_TIME,
            frec=TRAY_FREQ,
            th_i=th_i,
            x_f_dest=xi_f
        )

        # Después de calcular la trayectoria, medimos qué tan lejos quedó el final del objetivo (para evaluar precisión).
        th_f  = self.robot.th_m[:, -1]
        x_fin = np.asarray(self.robot.fk_num(*th_f)).flatten()
        error = np.linalg.norm(np.array(xi_f) - x_fin)
        self.get_logger().info(f"Estimación de llegada matemática → X={x_fin[0]:.3f}, Y={x_fin[1]:.3f}, Z={x_fin[2]:.3f} m")
        self.get_logger().info(f"Error (Qué tan desviado quedó): {error*100:.2f} cm")

        # ── GRÁFICAS MÁGICAS ──
        # Mandamos a generar los reportes visuales en otro proceso ("hilo daemon") para no trabar el programa principal de ROS.
        self.get_logger().info("Dibujando gráficas en segundo plano...")
        hilo_graficas = self.robot.lanzar_graficas_async('/tmp/robot_plots')
        self._hilo_graficas = hilo_graficas

        # ── ¡A MOVERNOS! ──
        # Iniciamos un timer que ejecutará 'timer_pub_callback' periódicamente para ir mandando las órdenes paso a paso a RViz.
        self.current_pos = 0
        self.timer_pub   = self.create_timer(1.0 / TRAY_FREQ, self.timer_pub_callback)
        self.get_logger().info(f"Iniciando movimiento suave ({self.robot.muestras} pasos en {TRAY_TIME}s)...")

    # ─────────────────────────────────────────────────────────────────────────
    def timer_pub_callback(self):
        """
        Esta función se ejecuta MUCHAS veces por segundo (a la frecuencia TRAY_FREQ).
        En cada ejecución, toma el SIGUIENTE PUNTITO de la trayectoria que calculó kinematics.py
        y se lo manda a los actuadores para que el robot avance un "cachito".
        """
        # Le ponemos la hora actual al mensaje para que ROS sepa que es información fresca.
        self.joint_state_msg.header.stamp = self.get_clock().now().to_msg()

        # Extraemos el ángulo exacto de cada junta correspondiente al pasito actual (current_pos).
        self.joint_state_msg.position = [
            float(self.robot.th_m[0, self.current_pos]),
            float(self.robot.th_m[1, self.current_pos]),
            float(self.robot.th_m[2, self.current_pos])
        ]

        # ¡Enviamos la orden! (Nuestros simuladores de motores lo escuchan en robot_actuators.py)
        self.js_pub.publish(self.joint_state_msg)
        self.current_pos += 1 # Avanzamos al contador para el siguiente paso

        # Si ya llegamos al último paso de toda la lista, paramos todo.
        if self.current_pos >= (self.robot.muestras - 1):
            self.is_moving = False        # Liberamos el sistema para que aceptes otro clic
            self.timer_pub.destroy()      # Destruimos este reloj para que descanse
            self.get_logger().info("¡Llegamos al destino!")
            self.get_logger().info("   Recuerda revisar tus gráficas frescas en: /tmp/robot_plots/")
            self.get_logger().info("   ├─ posicion_cartesiana.png")
            self.get_logger().info("   ├─ posicion_articular.png")
            self.get_logger().info("   └─ velocidad_articular.png")

    # ─────────────────────────────────────────────────────────────────────────
    def js_callback(self, msg: JointState):
        """Actualiza la posición articular actual del robot (realimentación)."""
        if len(msg.position) == len(JOINT_NAMES):
            self.js_current = msg


# ─────────────────────────────────────────────────────────────────────────────
def main():
    try:
        rclpy.init()
        publicador = PublicadorTrayectoria()
        rclpy.spin(publicador)
        rclpy.shutdown()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()