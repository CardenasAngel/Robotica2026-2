#!/usr/bin/env python3
"""
kinematics.py - Módulo central de cinemática con restricciones de seguridad
──────────────────────────────────────────────────────────────────────
Robot RRR Industrial 3D – Cinemática Directa e Inversa

Parámetros DH alineados con el URDF robot_rrr.urdf:
  - shoulder_joint en z=0.05m sobre base, shoulder_link mide 0.15m → h_total = 0.20m
  - arm_joint extiende 0.30m (l1)
  - forearm_joint extiende 0.25m (l2)

Método IK: Pseudoinversa del Jacobiano con corrección de error en lazo cerrado
──────────────────────────────────────────────────────────────────────
"""
from sympy import symbols, cos, sin, pi, Matrix, lambdify, simplify
import matplotlib
matplotlib.use('Agg')          # Backend no interactivo → seguro en ROS 2
import matplotlib.pyplot as plt
import numpy as np
import threading
import os

# ── Límites articulares (deben coincidir con el URDF) ──────────────────────
JOINT_LIMITS = [
    (-3.14159, 3.14159),   # shoulder_joint  (±180°)
    (0.05,     1.5708),    # arm_joint       (-115° a +90°) — ampliado para alcanzar puntos bajos
    (-2.6,     2.6),       # forearm_joint   (±149°)
]

# Ganancia del término de corrección de error de posición (lazo cerrado)
K_CORRECTION = 3.0


class Robot():
    def __init__(self, l=(0.20, 0.30, 0.25)):
        """
        Esta es la función de inicio de nuestra matemática.
        Aquí definimos físicamente cómo está construido el robot en metros.
        Parámetros:
            h  = Altura del poste de la base hasta la junta del hombro (0.20 m)
            l1 = El brazo principal (0.30 m)
            l2 = El antebrazo (0.25 m)
        """
        self.h, self.l1, self.l2 = l
        self.q1, self.q2, self.q3 = symbols('q1 q2 q3', real=True) # Nuestras 3 variables matemáticas (ángulos)

        # ── LAS FAMOSAS MATRICES DENAVIT-HARTENBERG (DH) ──
        # Aquí conectamos "hueso con hueso" matemáticamente usando dh_matrix().
        
        # 1. Base a Hombro: 
        # Sube por el poste de altura 'h'.
        # Usamos -pi/2 (-90°) en el último valor para "acostar" el eje Z matemático.
        # De esta forma, encaja perfectamente con cómo gira físicamente el robot en Y en el archivo URDF.
        self.T01 = self.dh_matrix(self.q1, self.h,  0,        -pi/2)  
        
        # 2. Hombro a Codo: Extiende la distancia 'l1' a lo largo del brazo.
        self.T12 = self.dh_matrix(self.q2, 0,       self.l1,  0)
        
        # 3. Codo a Punta: Extiende la distancia 'l2' a lo largo del antebrazo.
        self.T23 = self.dh_matrix(self.q3, 0,       self.l2,  0)

        # ── CÁLCULO ──
        # T03 es la suma de todas las rotaciones (Cinemática Directa Total).
        self.T03    = simplify(self.T01 * self.T12 * self.T23)
        # X_sym guarda explícitamente en dónde quedó la punta en [X, Y, Z]
        self.X_sym  = Matrix([self.T03[0, 3], self.T03[1, 3], self.T03[2, 3]])
        
        # Calculamos el Jacobiano: Es una matriz matemática que nos dice qué tan rápido se mueve
        # la punta si movemos una junta. ¡Esencial para saber cómo llegar a donde queremos!
        self.J_sym  = self.X_sym.jacobian([self.q1, self.q2, self.q3])

        # Convertimos las fórmulas simbólicas en funciones super rápidas de Numpy para no alentar la simulación.
        self.fk_num  = lambdify((self.q1, self.q2, self.q3), self.X_sym,  'numpy')
        self.jac_num = lambdify((self.q1, self.q2, self.q3), self.J_sym,  'numpy')

    # ─────────────────────────────────────────────────────────────────────────
    def def_tray(self, t_f, frec, th_i, x_f_dest):
        """
        Aquí calculamos paso a paso cómo mover los motores (ángulos) para llegar al destino 
        de forma súper suave y segura. 
        En lugar de geometría tradicional pesada, usamos Cinemática Inversa Diferencial.
        """
        dt = 1.0 / frec  # Tiempo entre cada "pasito" (ej. 0.02 segundos)
        self.muestras = int(t_f * frec) + 1  # ¿Cuántos pasitos daremos en total?
        
        # Preparamos arreglos vacíos (como cajas) para guardar toda la información 
        # que luego mandaremos a las gráficas:
        self.xi_m      = np.zeros((3, self.muestras))   # La posición 3D (x,y,z) por la que realmente pasamos
        self.xd_m      = np.zeros((3, self.muestras))   # La posición 3D por la que DEBÍAMOS pasar
        self.th_m      = np.zeros((3, self.muestras))   # Los ángulos de las juntas en cada paso
        self.th_dot_m  = np.zeros((3, self.muestras))   # La velocidad de cada motor (radiantes/segundo)

        q_act = np.array(th_i, dtype=float) # Arrancamos en los ángulos actuales
        x_ini = np.asarray(self.fk_num(*th_i)).flatten() # ¿Dónde estamos parados en X, Y, Z al iniciar?

        # SEGURIDAD: Evita que el brazo se estrelle contra el suelo (Z mínimo de 0.05m)
        x_final = np.array(x_f_dest, dtype=float)
        x_final[2] = max(x_final[2], 0.05)

        for k in range(self.muestras):
            # ── SUAVIZADO DE MOVIMIENTO (Perfil S-Curve de quinto orden) ──
            # Esta ecuación mágica asegura que el robot arranque suave, llegue a velocidad máxima a la mitad, y frene suavemente.
            tau   = min((k * dt) / t_f, 1.0)   # Avanza de 0 a 1 a lo largo del tiempo
            s     =   10*tau**3 - 15*tau**4 +  6*tau**5
            s_dot = (30*tau**2 - 60*tau**3 + 30*tau**4) / t_f

            # ¿Dónde deberíamos estar en este milisegundo exacto?
            x_deseada = x_ini + (x_final - x_ini) * s
            self.xd_m[:, k] = x_deseada

            # ¿Dónde estamos realmente? (Cinemática directa)
            x_actual = np.asarray(self.fk_num(*q_act)).flatten()
            self.xi_m[:, k] = x_actual

            # Obtenemos la matriz del Jacobiano en este instante
            J = np.asarray(self.jac_num(*q_act), dtype=float)

            # Calculamos con qué fuerza/velocidad empujarnos hacia el destino:
            # Una mezcla de la velocidad planeada (dx_ff) y un corrector si nos estamos desviando (dx_err).
            dx_ff  = (x_final - x_ini) * s_dot          
            dx_err = K_CORRECTION * (x_deseada - x_actual)   
            dx     = dx_ff + dx_err

            # ── MAGIA DE CINEMÁTICA INVERSA ──
            # Con el Jacobiano Pseudoinverso (pinv) convertimos velocidades XYZ en velocidades de los motores (q_dot)
            q_dot = np.linalg.pinv(J) @ dx

            # Aplicamos la velocidad y calculamos nuestros nuevos ángulos para el siguiente paso
            q_act = q_act + q_dot * dt

            # ── CUIDADO DE LOS MOTORES (Clamping) ──
            # Si el cálculo matemático dice "gira 360 grados", pero la junta física no puede,
            # 'clip' nos asegura que nos quedemos dentro de los límites físicos (JOINT_LIMITS).
            for i, (lo, hi) in enumerate(JOINT_LIMITS):
                q_act[i] = np.clip(q_act[i], lo, hi)

            # Guardamos los resultados para publicarlos y graficarlos después
            self.th_m[:, k]     = q_act
            self.th_dot_m[:, k] = q_dot

    # ── FUNCIONES DE GRÁFICAS ────────────────────────────────────────────────

    def imp_tray(self):
        """Gráfica de posición cartesiana real (x, y, z) del efector."""
        fig, axes = plt.subplots(1, 3, figsize=(13, 4))
        fig.suptitle("Posición Cartesiana del Efector Final (x, y, z)", fontsize=12, fontweight='bold')
        etiquetas = ['Pos X (m)', 'Pos Y (m)', 'Pos Z (m)']
        colores   = ['#e74c3c', '#2ecc71', '#3498db']
        for i, (lbl, col) in enumerate(zip(etiquetas, colores)):
            axes[i].plot(self.xi_m[i, :],  color=col,       label='Real',    linewidth=1.8)
            axes[i].plot(self.xd_m[i, :],  color='grey',    label='Deseada', linewidth=1.0, linestyle='--')
            axes[i].set_title(lbl); axes[i].grid(True, alpha=0.4); axes[i].legend(fontsize=8)
        plt.tight_layout()

    def imp_junt(self):
        """Gráfica de ángulos articulares (θ1, θ2, θ3) en radianes."""
        fig, axes = plt.subplots(1, 3, figsize=(13, 4))
        fig.suptitle("Posición Articular – Grados de Libertad (θ1, θ2, θ3)", fontsize=12, fontweight='bold')
        etiquetas = ['θ1 – Shoulder (rad)', 'θ2 – Arm (rad)', 'θ3 – Forearm (rad)']
        colores   = ['#9b59b6', '#e67e22', '#1abc9c']
        limites   = JOINT_LIMITS
        for i, (lbl, col, (lo, hi)) in enumerate(zip(etiquetas, colores, limites)):
            axes[i].plot(self.th_m[i, :], color=col, linewidth=1.8)
            axes[i].axhline(lo, color='red',  linestyle=':', linewidth=0.8, label=f'Lím inf {lo:.2f}')
            axes[i].axhline(hi, color='blue', linestyle=':', linewidth=0.8, label=f'Lím sup {hi:.2f}')
            axes[i].set_title(lbl); axes[i].grid(True, alpha=0.4); axes[i].legend(fontsize=7)
        plt.tight_layout()

    def imp_vel(self):
        """Gráfica de velocidades articulares (θ̇1, θ̇2, θ̇3) en rad/s."""
        fig, axes = plt.subplots(1, 3, figsize=(13, 4))
        fig.suptitle("Velocidad Articular (θ̇1, θ̇2, θ̇3)", fontsize=12, fontweight='bold')
        etiquetas = ['θ̇1 – Shoulder (rad/s)', 'θ̇2 – Arm (rad/s)', 'θ̇3 – Forearm (rad/s)']
        colores   = ['#c0392b', '#27ae60', '#2980b9']
        for i, (lbl, col) in enumerate(zip(etiquetas, colores)):
            axes[i].plot(self.th_dot_m[i, :], color=col, linewidth=1.8)
            axes[i].set_title(lbl); axes[i].grid(True, alpha=0.4)
        plt.tight_layout()

    def generar_graficas(self, output_dir='/tmp/robot_plots'):
        """
        Genera y guarda las 3 gráficas de rendimiento como archivos PNG.
        Llamar desde un hilo separado para no bloquear el spin de ROS.
        """
        os.makedirs(output_dir, exist_ok=True)
        plt.close('all')

        self.imp_tray()
        plt.savefig(os.path.join(output_dir, 'posicion_cartesiana.png'), dpi=120, bbox_inches='tight')

        self.imp_junt()
        plt.savefig(os.path.join(output_dir, 'posicion_articular.png'), dpi=120, bbox_inches='tight')

        self.imp_vel()
        plt.savefig(os.path.join(output_dir, 'velocidad_articular.png'), dpi=120, bbox_inches='tight')

        plt.close('all')
        return output_dir

    def lanzar_graficas_async(self, output_dir='/tmp/robot_plots'):
        """Lanza la generación de gráficas en un hilo daemon para no bloquear ROS."""
        hilo = threading.Thread(
            target=self.generar_graficas,
            args=(output_dir,),
            daemon=True
        )
        hilo.start()
        return hilo

    # ── MÉTODO ESTÁTICO DH ───────────────────────────────────────────────────
    @staticmethod
    def dh_matrix(theta, d, a, alpha):
        """
        Esta es la herramienta maestra de Denavit-Hartenberg. 
        Crea una matriz 4x4 que mueve nuestro sistema de coordenadas por el robot.
        Primero rota el ángulo de la junta (theta) en Z.
        Luego se desliza (d) sobre Z y (a) sobre X.
        Finalmente Tuerce todo (alpha) sobre X para encajar con la siguiente junta física.
        """
        return Matrix([
            [cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta)],
            [sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta)],
            [0,           sin(alpha),             cos(alpha),            d           ],
            [0,           0,                      0,                     1           ]
        ])