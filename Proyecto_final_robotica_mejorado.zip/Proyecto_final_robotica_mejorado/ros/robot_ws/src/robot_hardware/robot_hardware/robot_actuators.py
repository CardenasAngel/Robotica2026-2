#!/usr/bin/env python3
"""
robot_actuators.py
──────────────────────────────────────────────────────────────────────
Nodo ROS 2: Simulación del Hardware del Robot Industrial 3D.
Capa de abstracción que simula actuadores instantáneos sincronizados.

Versión Completa: Blindada contra desbordamiento y sincronizada con el 
planificador de trayectorias.
──────────────────────────────────────────────────────────────────────
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import numpy as np

# Nombres de las juntas oficiales del URDF
JOINT_NAMES = ["shoulder_joint", "arm_joint", "forearm_joint"]

# Sincronizado con postura inicial de imagen (debe ser igual a TH_INIT en el publicador)
# q1 =  0.00 rad (0°)   → shoulder recto
# q2 = -0.59 rad (-34°) → brazo inclinado hacia abajo (postura natural de referencia)
# q3 = -1.68 rad (-96°) → antebrazo recogido (postura natural de referencia)
TH_INIT = [0.0, -0.59, -1.68]

# Frecuencia del ciclo de hardware (100Hz = 10ms por ciclo)
HW_FREQ = 100

class NodoHardware(Node):
    def __init__(self):
        super().__init__("nodo_hardware")

        # PUBLICADOR: Aquí es donde el robot le dice a RViz "¡Aquí estoy físicamente!"
        # Publica en el tópico "/joint_states", que es el que RViz lee para dibujar el robot.
        self.js_pub = self.create_publisher(JointState, "/joint_states", 10)

        # SUSCRIPTOR: Aquí el robot escucha las "órdenes" de movimiento.
        # Escucha lo que el planificador de trayectorias calcula y envía.
        self.j_goal_sub = self.create_subscription(
            JointState, "/joint_states_goals", self.goal_callback, 10)

        # ESTADO REAL: Guardamos dónde creemos que están nuestros motores ahora mismo.
        self.js_state = JointState()
        self.js_state.name = JOINT_NAMES
        self.js_state.position = list(TH_INIT)

        # ESTADO DESEADO (META): Guardamos a dónde nos acaban de pedir que vayamos.
        self.js_goal = JointState()
        self.js_goal.name = JOINT_NAMES
        self.js_goal.position = list(TH_INIT)

        # RELOJ INTERNO (TIMER): Un ciclo repetitivo que corre a HW_FREQ Hz (ej. 100 veces por segundo).
        # Es como el "latido" del controlador de los motores.
        self.create_timer(1.0 / HW_FREQ, self.hw_callback)
        self.get_logger().info(f"Nodo hardware industrial listo. Posición inicial: {TH_INIT} rad")

    def goal_callback(self, msg: JointState):
        """
        Callback que recibe las metas articulares. 
        Básicamente, cuando alguien nos da una nueva instrucción de movimiento paso a paso, 
        esta función la atrapa.
        """
        if msg.position is not None and len(msg.position) > 0:
            try:
                # Extraemos la posición deseada y la "aplanamos" para evitar errores de formato raros.
                # Es como asegurarse de que los datos vengan en una lista limpia.
                pos_planas = np.array(msg.position).flatten().tolist()
                
                # Verificamos que al menos nos envíen información para todas nuestras juntas.
                if len(pos_planas) >= len(JOINT_NAMES):
                    self.js_goal.position = [float(x) for x in pos_planas[:len(JOINT_NAMES)]]
            except Exception as e:
                self.get_logger().error(f"Error al procesar posiciones de joints: {str(e)}")

    def hw_callback(self):
        """
        Ciclo de control constante. 
        Aquí simulamos que los motores son perfectos e instantáneos: 
        simplemente decimos que nuestra posición real ahora es igual a la meta deseada.
        """
        # Si la meta es válida, actualizamos nuestros motores simulados a esa posición.
        if self.js_goal.position and len(self.js_goal.position) == len(JOINT_NAMES):
            self.js_state.position = self.js_goal.position
        else:
            # Si nos mandaron algo inválido, nos quedamos quietos por seguridad.
            self.js_state.position = list(self.js_state.position)
            
        # Le ponemos la hora exacta al mensaje y lo mandamos a RViz para que actualice la pantalla 3D.
        self.js_state.header.stamp = self.get_clock().now().to_msg()
        self.js_pub.publish(self.js_state)

def main():
    try:
        rclpy.init()
        nodo_hardware = NodoHardware()
        rclpy.spin(nodo_hardware)
        rclpy.shutdown()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()