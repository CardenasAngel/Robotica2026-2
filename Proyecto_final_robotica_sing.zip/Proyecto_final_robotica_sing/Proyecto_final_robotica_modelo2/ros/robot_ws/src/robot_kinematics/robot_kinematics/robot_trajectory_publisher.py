#!/usr/bin/env python3
"""
robot_trajectory_publisher.py
──────────────────────────────────────────────────────────────────────
Nodo ROS 2: Publicador de Trayectoria para el Robot Antropomórfico 3D.
Sincronizado correctamente con el modelo cinemático espacial.
──────────────────────────────────────────────────────────────────────
"""
import rclpy
from rclpy.node import Node
from robot_kinematics.kinematics import Robot
from geometry_msgs.msg import Twist, PointStamped
from sensor_msgs.msg import JointState
import numpy as np

# Nombres de las juntas — coinciden exactamente con tu URDF
JOINT_NAMES = ["shoulder_joint", "arm_joint", "forearm_joint"]

# Dimensiones reales del robot según tu URDF (m)
L1, L2, L3 = 0.30, 0.25, 0.0   
H_BASE = 0.08  # Altura del poste central en el URDF

# Parámetros de la trayectoria
TRAY_TIME = 2      # segundos
TRAY_FREQ = 15     # Hz de muestreo

# Ángulos iniciales al arrancar (rad)
TH_INIT = (0.1, 0.1, 0.1)


class PublicadorTrayectoria(Node):
    def __init__(self):
        super().__init__("nodo_publicador_trayectoria")

        self.get_logger().info(
            f"Inicializando robot Antropomórfico: l1={L1}m, l2={L2}m (alcance máx = {L1+L2}m)"
        )
        self.robot = Robot(l=(L1, L2, L3))

        # ── Suscriptor: posición deseada (Twist) ──
        # x = msg.linear.x, y = msg.linear.y, z = msg.linear.z
        self.sub_twist = self.create_subscription(
            Twist,
            "/goals_twist",
            self.twist_callback,
            1)

        # ── Suscriptor: posición deseada por clic en RViz ──
        self.sub_ps = self.create_subscription(
            PointStamped,
            "/clicked_point",
            self.ps_callback,
            1)

        # ── Publicador y Suscriptor de estados de juntas ──
        self.js_pub = self.create_publisher(JointState, "/joint_states_goals", 1)
        self.js_sub = self.create_subscription(JointState, "/joint_states", self.js_callback, 10)

        # Variables de control
        self.is_moving = False
        self.current_pos = 0

        self.joint_state_msg = JointState()
        self.joint_state_msg.name = JOINT_NAMES

        self.js_current = JointState()
        self.js_current.name = JOINT_NAMES
        self.js_current.position = list(TH_INIT)

        self.get_logger().info("Nodo listo. Haz clic en RViz para mover el robot en el espacio 3D.")

    def _iniciar_trayectoria(self, xi_f: tuple):
        """
        Calcula la trayectoria 3D desde la postura actual hasta xi_f = (x, y, z)
        """
        th_i = (
            self.js_current.position[0],
            self.js_current.position[1],
            self.js_current.position[2]
        )
        self.get_logger().info(f"Ángulos iniciales: {[round(a,3) for a in th_i]}")
        self.get_logger().info(f"Postura final deseada EF -> X: {xi_f[0]:.3f}, Y: {xi_f[1]:.3f}, Z: {xi_f[2]:.3f}")

        # Validación del espacio de trabajo 
        dist_3d = np.sqrt(xi_f[0]**2 + xi_f[1]**2 + (xi_f[2] - H_BASE)**2)
        alcance_max = L1 + L2
        
        if dist_3d > alcance_max:
            self.get_logger().warn(
                f"Punto fuera del alcance máximo total ({dist_3d:.3f}m > {alcance_max}m). El Jacobiano no convergerá."
            )

        # Llamada a la cinemática espacial
        self.robot.def_tray(
            t_f=TRAY_TIME,
            frec=TRAY_FREQ,
            th_i=th_i,
            xi_f=xi_f
        )
        
        self.get_logger().info(
            f"Ángulos finales calculados: {[round(float(v), 3) for v in self.robot.th_m[:, self.robot.muestras-1]]}"
        )

        self.current_pos = 0
        self.timer_pub = self.create_timer(self.robot.dt, self.timer_pub_callback)

    def twist_callback(self, msg: Twist):
        if self.is_moving:
            return
        self.is_moving = True
        # Mapeo correcto de coordenadas espaciales desde Twist
        self._iniciar_trayectoria((msg.linear.x, msg.linear.y, msg.linear.z))

    def ps_callback(self, msg: PointStamped):
        if self.is_moving:
            self.get_logger().warn("Robot en movimiento, ignorando clic.")
            return
        self.is_moving = True
        
        # Capturamos el valor real enviado para evitar desfases.
        x_clic = msg.point.x
        y_clic = msg.point.y
        z_clic = msg.point.z  # Será 0.0 si es en el piso, o el valor exacto de la superficie elegida
        
        self.get_logger().info(f"Clic recibido en RViz: x={x_clic:.3f}, y={y_clic:.3f}, z={z_clic:.3f}")
        self._iniciar_trayectoria((x_clic, y_clic, z_clic))

    def timer_pub_callback(self):
        self.joint_state_msg.header.stamp = self.get_clock().now().to_msg()
        self.joint_state_msg.position = [
            float(self.robot.th_m[0, self.current_pos]),
            float(self.robot.th_m[1, self.current_pos]),
            float(self.robot.th_m[2, self.current_pos])
        ]
        self.js_pub.publish(self.joint_state_msg)
        self.current_pos += 1

        if self.current_pos >= (self.robot.muestras - 1):
            self.is_moving = False
            self.timer_pub.destroy()
            self.get_logger().info("Trayectoria completada. Robot listo.")

    def js_callback(self, msg: JointState):
        self.js_current = msg


def main():
    try:
        rclpy.init()
        publicador = PublicadorTrayectoria()
        rclpy.spin(publicador)
        rclpy.shutdown()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()