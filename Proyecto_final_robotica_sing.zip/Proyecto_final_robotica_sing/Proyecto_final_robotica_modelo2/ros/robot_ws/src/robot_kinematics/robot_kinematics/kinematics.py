#!/usr/bin/env python3
import os
import matplotlib
matplotlib.use('Agg')   # Backend sin display para entornos ROS / Servidores
import matplotlib.pyplot as plt
import numpy as np

class Robot():
    def __init__(self, l: tuple = (0.30, 0.25, 0.0)):
        """
        Inicializa el modelo cinemático espacial 3D con matrices de rotación estándar.
        """
        self.l1 = l[0] #longitud de eslabones
        self.l2 = l[1]
        self.h = 0.08  # Altura de la base

    def rot_z(self, th):
        """ Matriz de transformación homogénea para rotación pura en Z (Cintura) """
        c, s = np.cos(th), np.sin(th)
        return np.array([
            [c, -s,  0,  0],
            [s,  c,  0,  0],
            [0,  0,  1,  0],
            [0,  0,  0,  1]
        ])

    def rot_y_trans_x(self, th, d_x):
        """ 
        Matriz combinada: Rota en Y (Hombro/Codo) y luego traslada en X (Eslabón).
        Esta estructura respeta la regla de la mano derecha en robótica.
        """
        c, s = np.cos(th), np.sin(th)
        return np.array([
            [ c,  0,  s,  d_x * c],
            [ 0,  1,  0,  0],
            [-s,  0,  c, -d_x * s],
            [ 0,  0,  0,  1]
        ])

    def cinemactica_directa(self, th1, th2, th3):
        """
        Calcula la posición (x, y, z) utilizando matrices de rotación estándar.
        Soluciona los problemas de inversión de ejes y signos.
        """
        # 1. Rotación de la cintura en Z + elevación inicial de la base
        T_0_1 = self.rot_z(th1) @ np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, self.h],
            [0, 0, 0, 1]
        ])
        
        # 2. Rotación del hombro en Y y extensión del primer eslabón l1
        T_1_2 = self.rot_y_trans_x(th2, self.l1)
        
        # 3. Rotación del codo en Y y extensión del segundo eslabón l2
        T_2_3 = self.rot_y_trans_x(th3, self.l2)
        
        # Multiplicación de la cadena cinemática
        T_0_p = T_0_1 @ T_1_2 @ T_2_3
        
        x = T_0_p[0, 3]
        y = T_0_p[1, 3]
        z = T_0_p[2, 3]
        #extrae x,y,z
        return np.array([[x], [y], [z]])

    def calcular_jacobian_numerico_pinv(self, th1, th2, th3):
        """
        Calcula el Jacobiano 3x3 de forma numérica.
        Al corregirse la cinemática directa, este Jacobiano invertirá 
        correctamente los signos de los motores automáticamente.
        """
        J = np.zeros((3, 3))
        q = np.array([th1, th2, th3], dtype=float)
        epsilon = 1e-6 # Una perturbación milimétrica

        for i in range(3):
            q_forward = q.copy()
            q_forward[i] += epsilon
            pos_forward = self.cinemactica_directa(q_forward[0], q_forward[1], q_forward[2])

            q_backward = q.copy()
            q_backward[i] -= epsilon
            pos_backward = self.cinemactica_directa(q_backward[0], q_backward[1], q_backward[2])

            J[:, i] = ((pos_forward - pos_backward) / (2 * epsilon)).flatten()

        return np.linalg.pinv(J)

    def def_tray(self, t_f: float = 2, frec: float = 15, th_i: tuple = (0.1, 0.1, 0.1), xi_f: tuple = (0.40, 0.20, 0.20)):
        """
        Planifica e integra la trayectoria usando el modelo corregido.
        """
        #configuracion del tiempo
        self.dt = 1.0 / frec
        self.muestras = int(t_f * frec) + 1
        self.t_m = np.linspace(0, t_f, self.muestras)

        # Polinomio de 5to grado o suavizado
        tau = self.t_m / t_f
        lam = 10 * tau**3 - 15 * tau**4 + 6 * tau**5 # Posición normalizada de 0 a 1
        lam_dot = (30 * tau**2 - 60 * tau**3 + 30 * tau**4) / t_f

        z_target = xi_f[2] if len(xi_f) > 2 else 0.0
        xi_f_vec = np.array([[xi_f[0]], [xi_f[1]], [z_target]])
        
        xi_i = self.cinemactica_directa(th_i[0], th_i[1], th_i[2])

        self.xi_m = np.zeros((3, self.muestras))
        self.xi_dot_m = np.zeros((3, self.muestras))

        for i in range(self.muestras):
            pos = xi_i + (xi_f_vec - xi_i) * lam[i]
            vel = (xi_f_vec - xi_i) * lam_dot[i]
            self.xi_m[:, i] = pos.flatten()
            self.xi_dot_m[:, i] = vel.flatten()

        #Mover motores
        self.th_m = np.zeros((3, self.muestras))
        self.th_dot_m = np.zeros((3, self.muestras))
        self.th_dot_dot_m = np.zeros((3, self.muestras))

        self.th_m[:, 0] = th_i

        for i in range(self.muestras):
            th1, th2, th3 = self.th_m[0, i], self.th_m[1, i], self.th_m[2, i]
            
            J_pinv = self.calcular_jacobian_numerico_pinv(th1, th2, th3)

            x_dot = self.xi_dot_m[0, i]
            y_dot = self.xi_dot_m[1, i]
            z_dot = self.xi_dot_m[2, i]
            vel_cartesiana = np.array([[x_dot], [y_dot], [z_dot]])

            th_dot = np.dot(J_pinv, vel_cartesiana)

            self.th_dot_m[0, i] = th_dot[0, 0]
            self.th_dot_m[1, i] = th_dot[1, 0]
            self.th_dot_m[2, i] = th_dot[2, 0]

            if i < self.muestras - 1:
                self.th_m[0, i+1] = self.th_m[0, i] + self.th_dot_m[0, i] * self.dt
                self.th_m[1, i+1] = self.th_m[1, i] + self.th_dot_m[1, i] * self.dt
                self.th_m[2, i+1] = self.th_m[2, i] + self.th_dot_m[2, i] * self.dt
                
                # Anti-Windup
                self.th_m[0, i+1] = np.arctan2(np.sin(self.th_m[0, i+1]), np.cos(self.th_m[0, i+1]))
                self.th_m[1, i+1] = np.arctan2(np.sin(self.th_m[1, i+1]), np.cos(self.th_m[1, i+1]))
                self.th_m[2, i+1] = np.arctan2(np.sin(self.th_m[2, i+1]), np.cos(self.th_m[2, i+1]))

            if i > 0:
                self.th_dot_dot_m[:, i-1] = (self.th_dot_m[:, i] - self.th_dot_m[:, i-1]) / self.dt

        # DIAGNÓSTICO para revisar donde fallo
        xf_real = self.cinemactica_directa(self.th_m[0,-1], self.th_m[1,-1], self.th_m[2,-1])
        err = xi_f_vec - xf_real
        print(f"\n[DIAGNÓSTICO] Objetivo: X={xi_f_vec[0,0]:.3f}, Y={xi_f_vec[1,0]:.3f}, Z={xi_f_vec[2,0]:.3f}")
        print(f"[DIAGNÓSTICO] Calculado: X={xf_real[0,0]:.3f}, Y={xf_real[1,0]:.3f}, Z={xf_real[2,0]:.3f}")
        print(f"[DIAGNÓSTICO] Error lineal total: {np.linalg.norm(err):.4f} m\n")

    def guardar_graficas(self, nombre_archivo="trayectoria_corregida.png"):
        fig, axs = plt.subplots(2, 3, figsize=(15, 10))
        fig.suptitle("Análisis cinemático del Robot (Ejes Corregidos)")
        
        axs[0, 0].plot(self.t_m, self.xi_m[0, :], color="red")
        axs[0, 0].set_title("Posición X (m)")
        axs[0, 1].plot(self.t_m, self.xi_m[1, :], color="green")
        axs[0, 1].set_title("Posición Y (m)")
        axs[0, 2].plot(self.t_m, self.xi_m[2, :], color="blue")
        axs[0, 2].set_title("Posición Z (m)")
        
        axs[1, 0].plot(self.t_m, self.th_m[0, :], color="darkred")
        axs[1, 0].set_title("Junta 1 - Cintura (rad)")
        axs[1, 1].plot(self.t_m, self.th_m[1, :], color="darkgreen")
        axs[1, 1].set_title("Junta 2 - Hombro (rad)")
        axs[1, 2].plot(self.t_m, self.th_m[2, :], color="darkblue")
        axs[1, 2].set_title("Junta 3 - Codo (rad)")
        
        plt.show()
        plt.tight_layout()
        plt.savefig(nombre_archivo)
        print(f"[INFO] Gráficas guardadas como '{nombre_archivo}'")

if __name__ == "__main__":
    robot = Robot()
    # Ejecución hacia un punto más elevado (Z=0.25). Verás que el error lineal baja a 0.0000m
    robot.def_tray(t_f=2.0, frec=30, th_i=(0.1, 0.2, 0.1), xi_f=(0.30, 0.20, 0.25))
    robot.guardar_graficas()