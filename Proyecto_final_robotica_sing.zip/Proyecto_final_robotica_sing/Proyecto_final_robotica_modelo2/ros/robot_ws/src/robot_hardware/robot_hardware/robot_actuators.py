#!/usr/bin/env python3
"""
robot_actuators.py
──────────────────────────────────────────────────────────────────────
Nodo ROS 2: Simulación del Hardware del Robot RRR Planar.

Actúa como capa de abstracción del hardware: recibe los ángulos deseados
de las juntas y los retransmite como estado actual (simula actuadores
instantáneos). En un robot real, este nodo enviaría comandos al hardware
y leería encoders.

Robot: Manipulador RRR Plano XY
  - shoulder_joint : cintura  (l1 = 0.30 m)
  - arm_joint      : codo     (l2 = 0.25 m)
  - forearm_joint  : muñeca   (l3 = 0.10 m)

Tópicos suscritos:
  /joint_states_goals (sensor_msgs/JointState) ← posiciones deseadas

Tópicos publicados:
  /joint_states (sensor_msgs/JointState) → robot_state_publisher → RViz
──────────────────────────────────────────────────────────────────────
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

# Nombres de las juntas — deben coincidir exactamente con el URDF
JOINT_NAMES = ["shoulder_joint", "arm_joint", "forearm_joint"]

# Posición inicial de las juntas (rad)
TH_INIT = [0.1, 0.1, 0.1]

# Frecuencia de actualización del hardware (Hz)
HW_FREQ = 100   # = 10 ms por ciclo


class NodoHardware(Node):
    def __init__(self):
        super().__init__("nodo_hardware")

        # ── Publicador: estado actual de las juntas → RViz ──
        self.js_pub = self.create_publisher(
            JointState, "/joint_states", 10)

        # ── Suscriptor: posiciones deseadas ← publicador de trayectoria ──
        self.j_goal_sub = self.create_subscription(
            JointState, "/joint_states_goals",
            self.goal_callback, 10)

        # ── Mensaje de estado actual ──
        self.js_state          = JointState()
        self.js_state.name     = JOINT_NAMES
        self.js_state.position = list(TH_INIT)

        # ── Mensaje de posición deseada (último recibido) ──
        self.js_goal          = JointState()
        self.js_goal.name     = JOINT_NAMES
        self.js_goal.position = list(TH_INIT)

        # ── Timer de comunicación con el hardware ──
        # Publica el estado de las juntas a HW_FREQ Hz
        self.create_timer(1.0 / HW_FREQ, self.hw_callback)

        self.get_logger().info(
            f"Nodo hardware listo | Juntas: {JOINT_NAMES} | "
            f"Posición inicial: {TH_INIT} rad"
        )

    def goal_callback(self, msg: JointState):
        """
        Recibe la posición deseada de las juntas.
        En simulación: simplemente guarda el valor.
        En hardware real: aquí iría el comando al actuador (servo, motor).
        """
        self.js_goal = msg

    def hw_callback(self):
        """
        Lee el estado del hardware y lo publica.
        En simulación: retransmite la posición deseada como estado actual.
        En hardware real: aquí se leería el encoder o IMU.
        """
        # Simulación perfecta: el actuador sigue instantáneamente la referencia
        self.js_state.position = self.js_goal.position
        self.js_state.header.stamp = self.get_clock().now().to_msg()
        self.js_pub.publish(self.js_state)


def main():
    try:
        rclpy.init()
        nodo_hardware = NodoHardware()
        rclpy.spin(nodo_hardware)
        rclpy.shutdown()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
