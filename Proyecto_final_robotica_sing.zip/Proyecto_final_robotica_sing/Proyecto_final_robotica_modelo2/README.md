# 🤖 Proyecto Final — Robot RRR en Plano XY (ROS 2)

## ¿Qué es este proyecto?

Simulación de un **manipulador robótico de 3 grados de libertad (tipo RRR)** en el **plano XY**, desarrollada con **ROS 2** y visualizada en **RViz2**.

El modelo está basado en el siguiente diseño de pizarrón:

```
                    ◉ ← Efector final (punta de l₂)
                   /
      l₂ = 0.25 m /
                 /
                ◉ ← Junta 2 (arm_joint) — codo
               /
  l₁ = 0.30 m/
             /
            ◉ ← Junta 1 (shoulder_joint) — cintura
            │
           [h = 0.08 m]  ← Soporte vertical (poste)
            │
 ┌──────────┴────────────┐
 │   BASE GIRATORIA      │ ← Plataforma 0.40 × 0.20 × 0.05 m
 │   (shoulder_joint Z)  │   Junta 1: rota todo en el plano XY
 └───────────────────────┘
```

---

## Dimensiones del robot

| Componente | Descripción | Valor |
|---|---|---|
| **Base (plataforma)** | Largo × Ancho × Grosor | 0.40 × 0.20 × 0.05 m |
| **Soporte `h`** | Cilindro central (radio × altura) | r = 0.025 m, h = 0.08 m |
| **Eslabón 1 `l₁`** | Cintura → Codo (`shoulder_link`) | **0.30 m** |
| **Eslabón 2 `l₂`** | Codo → Efector final (`arm_link`) | **0.25 m** |
| **Alcance máximo** | `l₁ + l₂` | **0.55 m** |
| **Alcance mínimo** | `|l₁ − l₂|` (configuración plegada) | 0.05 m |

> El efector final es el **punto exacto en la punta de l₂** — no hay segmento extra.

---

## Grados de libertad

| # | Nombre de la junta | Tipo | Eje | Link padre → hijo | Acción |
|---|---|---|---|---|---|
| 1 | `shoulder_joint` | Revoluta | Z | `base_link` → `shoulder_link` | Rota l₁ + l₂ desde la base |
| 2 | `arm_joint` | Revoluta | Z | `shoulder_link` → `arm_link` | Rota l₂ desde el extremo de l₁ |
| 3 | `forearm_joint` | Revoluta | Z | `arm_link` → `forearm_link` | Controla orientación del EF |
| — | `tool_joint` | Fija | — | `forearm_link` → `tool_link` | Marca visual del EF (esfera) |

> Todos los ejes son **Z** → el robot opera en el **plano XY** (visto desde arriba).

---

## Lo que se ve al ejecutarlo

- 🖥️ **RViz2** con el brazo robótico 3D sobre una cuadrícula (plano XY)
- 🖱️ **Clic interactivo**: haz clic en el plano → el brazo se mueve suavemente al punto
- 📐 **Cinemática inversa**: calcula automáticamente los 3 ángulos de junta necesarios
- 📈 **Gráficas matplotlib**: posición del EF y ángulos de juntas vs. tiempo

---

## Estructura del proyecto

```
Proyecto_final_robotica/
│
├── README.md                            ← Este archivo
├── guia_ejecucion/
│   └── instrucciones.md                 ← Compilar y ejecutar
│
└── ros/
    └── robot_ws/
        └── src/
            │
            ├── robot_description/       ← Modelo 3D (URDF)
            │   ├── urdf/
            │   │   ├── robot_rrr.urdf       ← URDF principal ⭐
            │   │   └── robot_rrr_3.urdf     ← Versión xacro parametrizada
            │   ├── rviz/
            │   │   └── rviz.conf.rviz       ← Config de visualización
            │   └── meshes/
            │       └── link.stl             ← Malla STL (opcional)
            │
            ├── robot_kinematics/        ← Matemática del robot
            │   └── robot_kinematics/
            │       ├── kinematics.py               ← FK, Jacobiano, trayectorias
            │       └── robot_trajectory_publisher.py ← Nodo: clic → ángulos
            │
            ├── robot_hardware/          ← Simulación de actuadores
            │   └── robot_hardware/
            │       └── robot_actuators.py  ← Nodo: relay deseado → real
            │
            └── robot_bringup/           ← Launch files
                └── launch/
                    ├── trajectory_bringup.launch.py  ← ⭐ LANZADOR PRINCIPAL
                    └── rviz_bringup.launch.py        ← Solo viz + slider manual
```

---

## Arquitectura del sistema (flujo de datos)

```
 Usuario hace clic en el plano XY de RViz
              │
              ▼  /clicked_point (PointStamped)
 robot_trajectory_publisher.py
   → Cinemática directa   → postura inicial xi_i = [x_i, y_i, β_i]
   → Polinomio λ 5to orden → trayectoria suave del EF
   → Jacobiano J⁻¹         → cinemática inversa → θ̇ = J⁻¹ · ξ̇
              │
              ▼  /joint_states_goals (JointState)
     robot_actuators.py
   (simula actuadores — en físico: comandos a servomotores)
              │
              ▼  /joint_states (JointState)
 robot_state_publisher → RViz2
   (actualiza la posición del modelo 3D en pantalla)
```

---

## Cinemática

El módulo [`kinematics.py`](ros/robot_ws/src/robot_kinematics/robot_kinematics/kinematics.py) implementa:

| Paso | Descripción |
|---|---|
| **Cinemática directa** | Matrices de transformación homogénea T₀₁ · T₁₂ · T₂₃ |
| **Postura del EF** | `ξ = [x, y, β]` — posición 2D + orientación en plano XY |
| **Jacobiano J** | Derivadas parciales de ξ respecto a θ₁, θ₂, θ₃ |
| **Trayectoria λ** | Polinomio de 5to orden: suavidad en pos., vel. y aceleración |
| **Cinem. inversa** | Integración numérica: `Δθ = J⁻¹ · Δξ` paso a paso |

---

## Requisitos

- **OS**: Ubuntu 22.04 (recomendado) o 20.04
- **ROS**: ROS 2 Humble (recomendado) o Foxy
- **Paquetes ROS**: `rviz2`, `robot-state-publisher`, `xacro`, `joint-state-publisher-gui`
- **Python**: `sympy`, `matplotlib`

---

## Ejecución rápida

Ver [`guia_ejecucion/instrucciones.md`](guia_ejecucion/instrucciones.md) para los pasos detallados.

```bash
cd ros/robot_ws/
colcon build
source install/setup.bash
ros2 launch robot_bringup trajectory_bringup.launch.py
```

> **Uso**: En RViz, selecciona la herramienta **"Publish Point"** y haz clic en el plano XY.
> El robot se moverá suavemente hasta ese punto (máximo 0.55 m desde el origen).
