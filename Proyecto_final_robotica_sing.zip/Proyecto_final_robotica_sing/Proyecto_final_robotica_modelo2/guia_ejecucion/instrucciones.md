# Guía de Ejecución Completa — Robot RRR Plano XY
## Desde cero hasta ver el robot en pantalla

---

## 0. Requisitos del sistema

- **Ubuntu 22.04** (obligatorio — ROS 2 Humble solo corre en Ubuntu)
- Conexión a internet (primera instalación)
- La carpeta `Proyecto_final_robotica/` copiada en Ubuntu (desde Windows vía USB, compartida o clonada)

> Si estás en Windows, necesitas una máquina virtual Ubuntu o WSL2. Lo más sencillo es una VM con VirtualBox o VMware.

---

## PARTE 1 — Instalar ROS 2 Humble (solo la primera vez)

Abre una terminal en Ubuntu (`Ctrl + Alt + T`) y ejecuta los siguientes comandos **uno por uno**:

### 1.1 — Configurar los repositorios de ROS 2

```bash
sudo apt update && sudo apt install curl -y

sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
  http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

sudo apt update
```

### 1.2 — Instalar ROS 2 Humble (instalación completa)

```bash
sudo apt install ros-humble-desktop -y
```

> ⏳ Este paso tarda entre 5 y 15 minutos según tu internet. Espera a que termine.

### 1.3 — Instalar paquetes adicionales de ROS necesarios para el proyecto
S
```bash
sudo apt install \
  ros-humble-xacro \
  ros-humble-joint-state-publisher-gui \
  ros-humble-robot-state-publisher \
  python3-colcon-common-extensions \
  python3-pip -y
```

### 1.4 — Instalar las librerías de Python necesarias

```bash
pip3 install sympy matplotlib
```

**¿Cómo verifico que ROS 2 está instalado correctamente?**

```bash
source /opt/ros/humble/setup.bash
ros2 --version
```

Deberías ver algo como:
```
ros2 cli tools version 0.18.x
```

---

## PARTE 2 — Preparar el proyecto

### 2.1 — Cargar ROS 2 en la terminal (hacer esto SIEMPRE al abrir una terminal nueva)

```bash
source /opt/ros/humble/setup.bash
```

> 💡 **Tip**: Para no tener que escribirlo cada vez, agrégalo al archivo de configuración:
> ```bash
> echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
> source ~/.bashrc
> ```
> Después de esto, cada terminal nueva ya lo carga automáticamente.

### 2.2 — Navegar a la carpeta del workspace ROS

```bash
cd ~/Proyecto_final_robotica/ros/robot_ws
```

> ⚠️ Ajusta la ruta si pusiste el proyecto en otro lugar. Por ejemplo:
> - Si está en el escritorio: `cd ~/Desktop/Proyecto_final_robotica/ros/robot_ws`
> - Si está en Documentos: `cd ~/Documents/Proyecto_final_robotica/ros/robot_ws`

### 2.3 — Compilar el workspace

```bash
colcon build
```

Verás mensajes de compilación. Al final debe decir algo como:

```
Starting >>> robot_description
Starting >>> robot_hardware
Starting >>> robot_kinematics
Starting >>> robot_bringup
Finished <<< robot_description [Xs]
Finished <<< robot_hardware [Xs]
Finished <<< robot_kinematics [Xs]
Finished <<< robot_bringup [Xs]

Summary: 4 packages finished [XX.Xs]
```

> ⚠️ Si dice `Failed` en algún paquete, hay un error. Ve a la sección de solución de problemas al final.

> ⏳ La primera compilación puede tardar 1-3 minutos (sympy genera los cálculos simbólicos).

### 2.4 — Cargar el entorno del workspace

```bash
source install/setup.bash
```

> ⚠️ Este comando TAMBIÉN debes ejecutarlo cada vez que abras una terminal nueva (después de haber compilado). Hazlo SIEMPRE después del `source /opt/ros/humble/setup.bash`.

---

## PARTE 3 — Ejecutar el proyecto

### Opción A: Simulación completa con cinemática ⭐ (la que se pide en el proyecto)

En la misma terminal donde hiciste el `source`, ejecuta:

```bash
ros2 launch robot_bringup trajectory_bringup.launch.py
```

Verás que se abren **2 ventanas**:
1. 🖥️ **RViz2** — la ventana de visualización 3D con el robot
2. 📊 **Gráficas matplotlib** — aparecerán cuando hagas el primer movimiento

En la **terminal** verás mensajes como:
```
[INFO] [nodo_hardware]: Nodo hardware listo | Juntas: ['shoulder_joint', 'arm_joint', 'forearm_joint']
[INFO] [nodo_publicador_trayectoria]: Inicializando robot RRZ: l1=0.3m, l2=0.25m, l3=0.0m
[INFO] [nodo_publicador_trayectoria]: Nodo listo. Haz clic en el plano XY de RViz para mover el robot.
```

---

## PARTE 4 — Usar el robot en RViz

### 4.1 — Configurar la vista en RViz

Cuando se abra RViz, deberías ver el robot sobre una cuadrícula. Si no lo ves:

1. En el panel izquierdo, haz clic en **"Add"**
2. Selecciona **"RobotModel"** → OK
3. También agrega **"Grid"** para ver la cuadrícula del plano XY

### 4.2 — Hacer clic para mover el robot

1. En la barra superior de RViz, busca el ícono de **"Publish Point"**
   - Es un ícono con un punto y una flecha
   - También puedes ir al menú: `Tools → Publish Point`

2. **Haz clic en cualquier punto de la cuadrícula** (plano XY)

3. Verás que:
   - El brazo robótico se anima y se mueve hacia ese punto
   - En la terminal aparecen mensajes:
     ```
     [INFO] Clic recibido en RViz: x=0.300, y=0.150 (z ignorado)
     [INFO] Ángulos iniciales: [0.1, 0.1, 0.1]
     [INFO] Postura final EF: x=0.300, y=0.150, β=0.000
     [INFO] Ángulos finales: [0.524, -0.234, 0.873]
     [INFO] Trayectoria completada. Robot listo.
     ```
   - Se generan **2 gráficas matplotlib** con la trayectoria

### 4.3 — Workspace válido

El robot puede alcanzar puntos dentro de un **círculo de 0.55 m de radio** alrededor del origen.

```
          ↑ Y
          │    ╭───────╮
     0.55m│   ╱         ╲
          │  │    ✓ OK    │
          │  │            │
──────────┼──│────────────│──→ X
          │  │            │
          │   ╲         ╱
    -0.55m│    ╰───────╯
          │
```

> ❌ Si haces clic muy lejos del origen (> 0.55 m), la terminal te avisará y la cinemática puede no converger.

---

## PARTE 5 — ¿Cómo sé que todo se hizo bien?

### ✅ Lista de verificación visual

| Qué debes ver | Cómo verificar |
|---|---|
| Robot 3D en RViz | La ventana de RViz muestra la base gris, el soporte, el brazo cyan (l₁) y el brazo magenta (l₂) |
| Base rectangular | En la parte inferior del robot hay un rectángulo plano oscuro |
| Soporte vertical `h` | Un cilindro gris pequeño sube del centro de la base |
| Eslabón 1 `l₁` | Barra color **cian** de 0.30 m |
| Eslabón 2 `l₂` | Barra color **magenta** de 0.25 m |
| Esfera blanca EF | Bolita blanca en la punta del brazo magenta |
| Robot se mueve | Al hacer clic, el brazo se anima suavemente hacia el punto |
| Gráficas aparecen | Dos ventanas matplotlib con las curvas de posición x, y, β y los ángulos θ₁, θ₂, θ₃ |

### ✅ Verificación en terminal

Cuando el robot se mueve correctamente, debes ver en la terminal:

```
[INFO] [nodo_publicador_trayectoria]: Clic recibido en RViz: x=X.XXX, y=Y.YYY
[INFO] [nodo_publicador_trayectoria]: Ángulos iniciales: [...]
[INFO] [nodo_publicador_trayectoria]: Postura final EF: x=..., y=..., β=...
[INFO] [nodo_publicador_trayectoria]: Ángulos finales: [...]
[INFO] [nodo_publicador_trayectoria]: Trayectoria completada. Robot listo.
```

---

## PARTE 6 — Opción B: Solo visualización con sliders (modo manual)

Si solo quieres ver el modelo sin la cinemática:

```bash
ros2 launch robot_bringup rviz_bringup.launch.py
```

Se abre:
- RViz con el modelo 3D
- Un panel con **3 sliders** (uno por junta)
- Mueve los sliders para girar cada eslabón manualmente

---

## PARTE 7 — Solución de problemas

### ❌ "colcon: command not found"
```bash
sudo apt install python3-colcon-common-extensions -y
```

### ❌ "package 'robot_description' not found"
Olvidaste hacer source del workspace:
```bash
source install/setup.bash
```

### ❌ RViz se abre pero el robot no aparece
1. En RViz panel izquierdo → **Add** → **RobotModel** → OK
2. En "Fixed Frame" (panel izquierdo, arriba) cambia el valor a `base_link`

### ❌ Error de Python al iniciar
```bash
pip3 install --upgrade sympy matplotlib
```

### ❌ La terminal se llena de warnings naranjas de sympy
Es normal. Son advertencias de conversión de tipos, no afectan el funcionamiento.

### ❌ El robot no se mueve al hacer clic
- Verifica que la herramienta activa sea **"Publish Point"** (no "Interact" ni "Move Camera")
- Espera 2 segundos después del movimiento anterior
- El punto debe estar dentro del círculo de 0.55 m de radio

---

## Resumen de comandos (copiar y pegar en orden)

```bash
# Terminal nueva — ejecutar en orden:
source /opt/ros/humble/setup.bash
cd ~/Proyecto_final_robotica/ros/robot_ws
colcon build
source install/setup.bash
ros2 launch robot_bringup trajectory_bringup.launch.py
```
